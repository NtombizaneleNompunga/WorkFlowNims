package pages.Mss.contract;

import java.io.IOException;

import org.testng.annotations.Test;

import com.test.NIMS.pages.Mss;
import com.test.NIMS.util.Utility;

public class mssContract extends Mss {

	@Test(dataProviderClass= Utility.class, dataProvider="MSS",priority =5)
	public void createMssContract(String startdate, String poNum, String billDuration, String deliverySite, String CenterId, 
			String plannedEffort, String effortUnit, String associateName, String associate, String cliDesignation, 
			String approver, String peakSize, String billClientName, String billDesignation, String billContact, 
			String billEmail, String projectName, String projDesignation, String projContact, String projEmail, 
			String softwareName, String licence, String payableBy, String numLicence, String processorType, String primaryMem, 
			String secMemory, String operSystem, String payableBy2, String role, String quantity, String rate, 
			String unit, String location, String noOfHours,String description) throws IOException, InterruptedException{
		
		
		MSS(startdate, poNum, billDuration, deliverySite, CenterId, plannedEffort, effortUnit, associateName,
				associate, cliDesignation, approver, peakSize, billClientName, billDesignation, billContact, billEmail,
				projectName, projDesignation, projContact, projEmail, softwareName, numLicence, payableBy, licence, processorType, 
				primaryMem, secMemory, operSystem, payableBy2, role, quantity, rate, unit, location,noOfHours, description);
		
	}

}
