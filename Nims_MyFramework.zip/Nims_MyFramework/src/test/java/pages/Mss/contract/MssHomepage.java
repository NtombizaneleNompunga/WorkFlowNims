package pages.Mss.contract;

import org.testng.annotations.Test;

import com.test.NIMS.pages.HomePage;

public class MssHomepage extends HomePage{
	@Test(priority =4)
	public void mssHome() throws InterruptedException{
	navigateMss();

}
}