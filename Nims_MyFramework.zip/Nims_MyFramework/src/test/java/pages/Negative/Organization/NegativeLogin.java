package pages.Negative.Organization;

import java.io.IOException;

import org.testng.annotations.Test;

import com.test.NIMS.pages.LoginPage;
import com.test.NIMS.util.Utility;

public class NegativeLogin extends LoginPage{
	
	@Test(dataProvider="LoginNeg1",priority=1)
	public void neg(String username,String organ) throws IOException{
		loginNeg1(username,organ);
		Screenshot();
	}
	
	@Test(dataProvider="LoginNeg2",priority=2)
	public void neg1(String username,String organ) throws IOException{
		loginNeg2(username,organ);
		Screenshot();
	}
}
