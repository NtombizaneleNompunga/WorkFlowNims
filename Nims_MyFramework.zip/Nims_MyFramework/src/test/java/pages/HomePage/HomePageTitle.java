package pages.HomePage;

import org.testng.annotations.Test;

import com.test.NIMS.base.NIMSBase;
import com.test.NIMS.pages.HomePage;

public class HomePageTitle extends NIMSBase{
	
	HomePage homePage;
	
	@Test(priority =0)
	public void homePageTitleTest()throws InterruptedException {
		
		Thread.sleep(3000);
		super.launch();
	}
	

}
