package pages.DAM.Approval;

import org.testng.annotations.Test;

import com.test.NIMS.pages.DEX_Approver;
import com.test.NIMS.pages.DexApproverLogin;

public class DAM_Login extends DexApproverLogin{
	@Test(dataProvider="FinanceLogin", priority=9)
	public void LoginDex(String username,String Organ){
		LoginApprover(username,Organ);
	}
	
	@Test(dataProvider="DAMApprover", priority=10)
	public void DEX_ApproverCall(String docId,String ProjectName,String DAM,String DEX ) throws InterruptedException{
		DEX_Approver obj =new DEX_Approver();
		obj.DEX_Approver(docId, ProjectName, DAM, DEX);
	}

}
