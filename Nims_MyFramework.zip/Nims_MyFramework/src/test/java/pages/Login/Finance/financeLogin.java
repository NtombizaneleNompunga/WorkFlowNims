package pages.Login.Finance;

import java.io.IOException;

import org.testng.annotations.Test;

import com.test.NIMS.pages.LoginFinance;

public class financeLogin  extends LoginFinance{
	@Test(dataProvider="FinanceLogin", priority=6)
	public void LogFinance(String username,String Organ) throws IOException{
		loginFinance(username,Organ);
	}

}
