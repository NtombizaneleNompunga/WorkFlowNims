package pages.loginPage;

import java.io.IOException;

import org.testng.annotations.Test;

import com.test.NIMS.base.NIMSBase;
import com.test.NIMS.pages.LoginPage;
import com.test.NIMS.util.Utility;

public class LoginTest extends LoginPage{
	
	@Test(dataProviderClass=Utility.class,dataProvider="ABC",priority =3)
	public void loginTest(String username, String organ) throws IOException{
		login(username, organ);
	
	}

}
