package pages.Finance.Navigation;
import org.testng.annotations.Test;

import com.test.NIMS.pages.Finance;


public class keysFinance extends Finance {
	@Test(dataProvider="Finance",priority=8)
	public void Finance(String contractName,String bizUnit,String remarks){
		finance(contractName,bizUnit,remarks);
		
	}

}
