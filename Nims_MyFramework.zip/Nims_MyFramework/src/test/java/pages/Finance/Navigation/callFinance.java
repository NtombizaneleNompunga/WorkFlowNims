package pages.Finance.Navigation;

import org.testng.annotations.Test;

import com.test.NIMS.pages.Finance;

public class callFinance extends Finance {
	@Test(priority=7)
	public void financeNavigation(){
		navigateToFinance();
	}

}
