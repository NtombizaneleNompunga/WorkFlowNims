package com.test.NIMS.pages;

import org.openqa.selenium.By;

import com.test.NIMS.base.NIMSBase;

public class HomePage extends NIMSBase{
	
	 public void navigateMss() throws InterruptedException{
		 
		 driver.findElement(By.xpath("//a[contains(@class,'drop has-submenu') and text()='MSS']")).click();
			
			driver.findElement(By.xpath("//a[contains(@class,'hyperlinkrclick has-submenu') and text()='Marketing Sales And Service']")).click();

			driver.findElement(By.xpath("//a[contains(text(),'Contract Signed')]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[contains(text(),'manoj-test1-Contract2')]")).click();
			Thread.sleep(2000);

	 }

	
	

}
