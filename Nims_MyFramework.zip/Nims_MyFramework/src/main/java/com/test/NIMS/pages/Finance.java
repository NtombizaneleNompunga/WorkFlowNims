package com.test.NIMS.pages;

import org.openqa.selenium.By;

import com.test.NIMS.base.NIMSBase;

public class Finance extends NIMSBase{
	
	public void navigateToFinance(){
		driver.findElement(By.xpath("//a[contains(@class,'drop has-submenu') and text()='Finance']")).click();
		
		driver.findElement(By.xpath("//a[contains(@class,'hyperlinkrclick has-submenu') and text()='Contract']")).click();

		driver.findElement(By.xpath("//a[contains(@class,'hyperlink') and text()=' Contract '] ")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'manoj-test1-Contract1')] ")).click();
	}
	
	
	public void finance(String contractName,String bizUnit,String remarks){
	
	
	driver.findElement(By.xpath("//input[@id='contractName'] ")).sendKeys(contractName);
	
	driver.findElement(By.xpath("//select[@id='bizUnitNameId'] ")).sendKeys(bizUnit);
	
	driver.findElement(By.xpath("//textarea[@id='remarks'] ")).sendKeys(remarks);
	
	driver.findElement(By.xpath("//select[@id='documentId'] ")).sendKeys(" ");
	
	//cannot click approve button still need to verify signed contract.
	//driver.findElement(By.xpath("//input[@id='verifyButton']")).click();
	driver.findElement(By.xpath("//a[text()='Signout']")).click();
	 

}
}
