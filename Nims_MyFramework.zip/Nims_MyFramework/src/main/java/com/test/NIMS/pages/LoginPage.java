package com.test.NIMS.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.test.NIMS.base.NIMSBase;
import com.test.NIMS.util.Utility;


public class LoginPage extends NIMSBase{
	//@Test(dataProvider="ABC",priority =2)
	//@Test(dataProviderClass=Utility.class,dataProvider="ABC",priority =2)
	public void loginNeg1(String username,String organ) throws IOException{
		
		driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys(username);
		driver.findElement(By.xpath("//select[@name='companyIdOnSign']")).sendKeys(organ);
		driver.findElement(By.xpath("//input[@id='loginBtn']")).click();
			
			wb.close();
			String expect= "NIMS~";
			String actual= driver.getTitle();
			
			if (expect==actual){
				System.out.println("User is able to login");
			}else{
				System.out.println("Invalid Page");
				//driver.close();
			}

	 }

	public void loginNeg2(String username,String organ) throws IOException{
		
		driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys(username);
		driver.findElement(By.xpath("//select[@name='companyIdOnSign']")).sendKeys(organ);
		driver.findElement(By.xpath("//input[@id='loginBtn']")).click();
			
			wb.close();
			String expect= "NIMS~";
			String actual= driver.getTitle();
			
			if (expect==actual){
				System.out.println("User is able to login");
			}else{
				System.out.println("Invalid Page");
				//driver.close();
			}

	 }

	public void login(String username,String organ) throws IOException{
	
		driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys(username);
		driver.findElement(By.xpath("//select[@name='companyIdOnSign']")).sendKeys(organ);
		driver.findElement(By.xpath("//input[@id='loginBtn']")).click();
			
			wb.close();
			String expect= "NIMS~";
			String actual= driver.getTitle();
			
			if (expect==actual){
				System.out.println("User is able to login");
			}else{
				System.out.println("Invalid Page");
				//driver.close();
			}

	 }

	}

