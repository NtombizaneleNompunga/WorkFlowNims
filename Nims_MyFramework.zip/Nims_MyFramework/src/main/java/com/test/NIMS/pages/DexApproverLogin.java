package com.test.NIMS.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.test.NIMS.base.NIMSBase;

public class DexApproverLogin extends NIMSBase{
	
	
	public void LoginApprover(String username,String Organ){
		WebDriverWait  wait= new WebDriverWait(driver, 5);
		
		driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys(username);
		driver.findElement(By.xpath("//select [@id='cookieValue']")).sendKeys(Organ);
		driver.findElement(By.xpath("//input[@class='btn']")).click();

	}
	
	

}
