package com.test.NIMS.pages;

import java.io.IOException;

import org.openqa.selenium.By;

import com.test.NIMS.base.NIMSBase;

public class LoginFinance extends NIMSBase{
		
		public void loginFinance(String username,String organ) throws IOException{
		
			driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys(username);
			driver.findElement(By.xpath("//select[@name='companyIdOnSign']")).sendKeys(organ);
			driver.findElement(By.xpath("//input[@id='loginBtn']")).click();
				
				wb.close();
				String expect= "NIMS~";
				String actual= driver.getTitle();
				
				if (expect==actual){
					System.out.println("User is able to login");
				}else{
					System.out.println("Invalid Page");
					//driver.close();
				}

		 }

		}




