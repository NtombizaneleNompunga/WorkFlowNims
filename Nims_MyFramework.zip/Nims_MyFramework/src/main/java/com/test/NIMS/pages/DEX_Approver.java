package com.test.NIMS.pages;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.test.NIMS.base.NIMSBase;

public class DEX_Approver extends NIMSBase{

	public void DEX_Approver(String docId,String ProjectName,String DAM,String DEX ) throws InterruptedException{
		driver.findElement(By.xpath("//a[contains(@class,'drop has-submenu') and text()='My Profile']")).click();
		driver.findElement(By.xpath("//a[contains(@class,'hyperlinkrclick has-submenu') and text()='PIC']")).click();
		driver.findElement(By.xpath("//a[contains(@class,'hyperlinkrclick') and text()=' Pending Project Initiation Form for Approver ']")).click();

		driver.findElement(By.xpath("//a[contains(text(),'Ankita_PROD_TEST_FPB3')]")).click();
		driver.findElement(By.xpath("//td[@id='slideupdown1']")).click();
		
		driver.findElement(By.xpath("//select[@id='documentId']")).sendKeys(docId);
		driver.findElement(By.xpath("//input[@id='projectName']")).sendKeys(ProjectName);
		
		driver.findElement(By.xpath("//input[@id='dam']")).sendKeys(DAM);
		driver.findElement(By.xpath("//input[@id='dex']")).sendKeys(DEX);
		//driver.findElement(By.xpath("//input[@id='approveBtn']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Signout']")).click();

		
	}

}
