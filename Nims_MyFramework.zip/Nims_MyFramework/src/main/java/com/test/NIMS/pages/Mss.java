package com.test.NIMS.pages;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.test.NIMS.base.NIMSBase;
import com.test.NIMS.util.Utility;

public class Mss extends NIMSBase {
	//@Test(dataProvider="MSS",priority =4)
		 public void MSS(String startdate,String poNum,String billDuration, String deliverySite,String CenterId,String plannedEffort,String effortUnit,String associateName ,String associate ,String cliDesignation
				 ,String approver ,String peakSize ,String billClientName ,String billDesignation ,String billContact,String billEmail ,String projectName ,String projDesignation,String projContact ,String projEmail,
				 String softwareName,String licence,String payableBy ,String numLicence,String processorType,String primaryMem,String secMemory ,String operSystem ,String payableBy2,String role,String quantity,String rate,String unit,
				String location ,String noOfHours,String description ) throws IOException, InterruptedException{
		
			 	driver.findElement(By.xpath("//input[@id='contractStartDate']")).click();//.sendKeys(startdate);
				driver.findElement(By.xpath("//a[contains(@class,'ui-state-default') and text()='6']")).click();
				// Thread.sleep(2000);
				//driver.findElement(By.xpath("//input[@id='contractEndDate'])")).click();
				driver.findElement(By.xpath("//a[contains(@class,'ui-state-default')and text()='8']")).click();

				driver.findElement(By.xpath("//input[@id='poNo']")).sendKeys(poNum);
				driver.findElement(By.xpath("//select[@id='billingDuration']")).sendKeys(billDuration);
				
				driver.findElement(By.xpath("//select[@id='deliverySiteId']")).sendKeys(deliverySite);
				
				driver.findElement(By.xpath("//select[@id='costCentreId']")).sendKeys(CenterId);
				
				driver.findElement(By.xpath("//input[@id='new']")).click();
				
				driver.findElement(By.xpath("//input[@id='plannedEffort']")).sendKeys(plannedEffort);

				driver.findElement(By.xpath("//select[@id='plannedEffortUnit']")).sendKeys(effortUnit);
				
				driver.findElement(By.xpath("//input[@id='signedOn']")).click();
				driver.findElement(By.xpath("//a[contains(@class,'ui-state-default')and text()='8']")).click();

				
				//driver.get("C:\\Users\\s987211\\Desktop\\fileupload.html");
				driver.findElement(By.xpath("//input[@id='file']")).click();
				Runtime.getRuntime().exec("C:\\Users\\s987211\\Desktop\\AutoIt\\FileUpload.exe");
				
				driver.findElement(By.xpath("//input[@id='nihilentSignatorys[0].associateName']")).sendKeys(associateName);

				driver.findElement(By.xpath("//input[@id='mssList[0].associate']")).sendKeys(associate);
				
				driver.findElement(By.xpath("//input[@id='mssList[0].clientDesignation']")).sendKeys(cliDesignation);
				
				driver.findElement(By.xpath("//select[@id='mssApprover']")).sendKeys(approver);
				
				driver.findElement(By.xpath("//input[@id='peakTeamSizeWritee']")).sendKeys(peakSize);
				
				//new Select (driver.findElement(By.xpath("//select[@id='documentId']"))).selectByIndex(2);
				
				driver.findElement(By.xpath("//input[@id='billingClientname']")).sendKeys(billClientName);
				
				driver.findElement(By.xpath("//input[@id='billingClientDesignation']")).sendKeys(billDesignation);

				driver.findElement(By.xpath("//input[@id='billingClientContact']")).sendKeys(billContact);
				
				driver.findElement(By.xpath("//input[@id='billingClientEmail']")).sendKeys(billEmail);

				driver.findElement(By.xpath("//input[@id='projectContractName']")).sendKeys(projectName);
				driver.findElement(By.xpath("//input[@id='projectDesignation']")).sendKeys(projDesignation);
				driver.findElement(By.xpath("//input[@id='projectContact']")).sendKeys(projContact);
				driver.findElement(By.xpath("//input[@id='projectEmail']")).sendKeys(projEmail);
				
				driver.findElement(By.xpath("//td[@id='slideupHardwareSoftware']")).click();
				
				driver.findElement(By.xpath("//input[@name='proposalSoftwareRequirements[0].nameOfSoftware']")).sendKeys(softwareName);

				driver.findElement(By.xpath("//input[@name='proposalSoftwareRequirements[0].licence']")).sendKeys(licence);
				
				driver.findElement(By.xpath("//input[@name='proposalSoftwareRequirements[0].payableBy']")).sendKeys(payableBy);
				
				driver.findElement(By.xpath("//input[@name='proposalSoftwareRequirements[0].nooflicence']")).sendKeys(numLicence);
				
				driver.findElement(By.xpath("//input[@name='proposalHardwareRequirements[0].processorType']")).sendKeys(processorType);

				driver.findElement(By.xpath("//input[@name='proposalHardwareRequirements[0].primaryMemory']")).sendKeys(primaryMem);
				
				driver.findElement(By.xpath("//input[@name='proposalHardwareRequirements[0].secondaryMemory']")).sendKeys(secMemory);
				
				driver.findElement(By.xpath("//input[@name='proposalHardwareRequirements[0].os']")).sendKeys(operSystem);
				
				driver.findElement(By.xpath("//input[@name='proposalHardwareRequirements[0].payableBy']")).sendKeys(payableBy2);
				
				driver.findElement(By.xpath("//input[@name='contractResourceSplitFormList[0].role']")).sendKeys(role);
				
				driver.findElement(By.xpath("//input[@name='contractResourceSplitFormList[0].quantity']")).sendKeys(quantity);
				
				driver.findElement(By.xpath("//input[@name='contractResourceSplitFormList[0].rate']")).sendKeys(rate);
				
				driver.findElement(By.xpath("//select[@name='contractResourceSplitFormList[0].unitOfMeasure']")).sendKeys(unit);
				
				driver.findElement(By.xpath("//select[@name='contractResourceSplitFormList[0].location']")).sendKeys(location);
				
				//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='startDate_0']")));
				//Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id='startDate_0']")).click();//sendKeys("06/19/2019");
				
				//Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id='tblfpb']/tbody/tr[2]/td[6]/img")).click();
			
				//Thread.sleep(2000);
				driver.findElements(By.xpath("//a[contains(@class,'ui-state-default')and text()='1']")).get(1).click();
				
				Thread.sleep(2000);
				driver.findElements(By.xpath("//img[@class='ui-datepicker-trigger']")).get(4).click();
				
				Thread.sleep(2000);
				driver.findElements(By.xpath("//a[contains(@class,'ui-state-default')and text()='10']")).get(1).click();
				
				driver.findElement(By.xpath("//input[@id='noofhours_0']")).sendKeys(noOfHours);
				Thread.sleep(2000);
				//Alert al= driver.switchTo().alert();
				//al.accept();
				
				driver.findElement(By.xpath("//input[@id='contractResourceSplitFormList[0].description']")).sendKeys(description);

				//driver.findElement(By.xpath(""))
				Thread.sleep(2000);
				driver.findElement(By.xpath("//a[text()='Signout']")).click();
		 }

	

}
