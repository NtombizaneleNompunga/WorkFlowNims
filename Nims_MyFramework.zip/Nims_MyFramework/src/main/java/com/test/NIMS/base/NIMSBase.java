package com.test.NIMS.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.test.NIMS.util.Utility;

public class NIMSBase extends Utility{

	public static WebDriver driver;
	public static Properties prop;

	public NIMSBase() {

		prop = new Properties();
		try {
			FileInputStream fileInput = new FileInputStream(System.getProperty("user.dir")
					+ "//src//main//java//com//test//NIMS//" + "config//config.properties");
			prop.load(fileInput);

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
    
	public void launch() {

		String browserType = prop.getProperty("browser");

		if (browserType.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\s987211\\Downloads\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-infobars");
			driver = new ChromeDriver(options);

		} else if (browserType.equalsIgnoreCase("firefox")) {
			// TODO write code for Firefox

		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		
	}
/*public static void click(By element) {
		
		try {
			driver.findElement(element).click();
			System.out.println("Element got clicked successfully");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Not able to click the element");
		}
		
	}
		
		public static void sendKeys(By element, String text) {
			
			try {
				driver.findElement(element).sendKeys(text);
				System.out.println("Element got clicked successfully");
				
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Not able to enter text");
			}
		}*/
}