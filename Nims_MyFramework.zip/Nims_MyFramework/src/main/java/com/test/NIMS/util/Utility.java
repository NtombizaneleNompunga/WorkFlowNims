package com.test.NIMS.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.test.NIMS.base.NIMSBase;

public class Utility {
	
	public static long WAIT_TIME = 10;
	public static long PAGE_LOAD_TIMEOUT = 30;
	public static long ELEMENT_TIMEOUT = 30;
	//protected static WebDriver driver;
	//String datas[][] =new String[1][2];
	
	protected XSSFWorkbook wb;
	
	@BeforeTest
	@DataProvider(name="ABC")
	
	public Object[][]readExcel() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheetAt(0);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}
	@BeforeTest
	@DataProvider(name="MSS")
	public Object[][]readExcelMss() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheetAt(2);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}
	@BeforeTest
	@DataProvider(name="FinanceLogin")
	public Object[][]readExcelFinancelogin() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheetAt(1);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}


	
	@BeforeTest
	@DataProvider(name="Finance")
	public Object[][]readExcelFinance() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheetAt(3);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}
	
	@BeforeTest
	@DataProvider(name="LoginNeg1")
	public Object[][]readExcelLogNeg1() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheetAt(5);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}

	@BeforeTest
	@DataProvider(name="LoginNeg2")
	public Object[][]readExcelLogNeg2() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheetAt(4);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}
	public static void Screenshot() throws IOException{
		String  dateTime = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss").format(new Date());
		File src= ((TakesScreenshot)NIMSBase.driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\Users\\s987211\\Desktop\\LoginScreenshot\\"+dateTime+".png"));
		
	}
	@BeforeTest
	@DataProvider(name="DAMApprover")
	public Object[][]readExcelLogDAM() throws IOException{ //Object used to return the data in the sheet...you can also write Object instead of String, it will still reeturn a string value
		File fs = new File("C:\\Users\\s987211\\Desktop\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheet("Sheet 3");//getSheetAt(6);
		int rowCount= xs.getPhysicalNumberOfRows();
		int columnCount=xs.getRow(0).getLastCellNum();
		System.out.println(rowCount);
		System.out.println(columnCount);
		String datas[][] =new String[rowCount-1][columnCount];
		for (int i =1;i<rowCount;i++){
			
			for(int j=0;j<columnCount;j++){
				String cellValue = xs.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
				datas[i-1][j]=cellValue;
				
			}
		}
		return datas;
		
		
		
	}


	



}





